function hideInactiveControls(){

    $('[data-smodx-behav="recount"]').remove();

}