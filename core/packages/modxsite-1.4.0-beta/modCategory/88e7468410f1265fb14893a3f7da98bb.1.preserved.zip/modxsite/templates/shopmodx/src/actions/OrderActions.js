"use_strict";

// var Dispatcher = require("../core/Dispatcher");
var API = require("../utils/API");

module.exports = {
  shouldRemoveGood: API.removeGood,
  shouldRecountOrder: API.recountOrder
};
