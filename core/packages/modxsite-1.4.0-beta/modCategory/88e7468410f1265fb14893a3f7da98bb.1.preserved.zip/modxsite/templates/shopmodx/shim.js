module.exports = {
  "jQuery": {
    "exports": "global:window.jQuery"
  },
  "Alertify": {
    "exports": "global:alertify"
  }
};
