module.exports = {
  GOOD_ADD: 'products/add',
  GOOD_REMOVE: 'products/remove',
  CART_RESET: 'reset',
  CART_REFRESH: 'getdata',
  ORDER_REFRESH: 'ORDER_REFRESH',
  ORDER_RECOUNT: 'recalculate'
};
