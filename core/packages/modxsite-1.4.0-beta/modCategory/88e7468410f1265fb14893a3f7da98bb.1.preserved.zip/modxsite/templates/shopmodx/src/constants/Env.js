module.exports = {
  connectorsUrl: 'assets/components/basket/connectors/',
  siteConnectorsUrl: 'assets/components/modxsite/connectors/',
  connector: 'connector.php'
};