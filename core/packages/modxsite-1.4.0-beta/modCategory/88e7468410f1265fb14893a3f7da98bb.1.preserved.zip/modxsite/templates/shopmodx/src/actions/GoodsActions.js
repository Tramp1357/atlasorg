"use_strict";

var Dispatcher = require("../core/Dispatcher");
var API = require("../utils/API");

module.exports = {
  shouldAddToCart: API.addGoodToCart
};
