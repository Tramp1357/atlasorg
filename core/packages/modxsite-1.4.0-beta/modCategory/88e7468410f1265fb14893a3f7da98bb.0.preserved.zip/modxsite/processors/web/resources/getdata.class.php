<?php

require_once dirname(dirname(dirname(__FILE__))).'/site/web/resources/getdata.class.php';

class modWebResourcesGetdataProcessor extends modSiteWebResourcesGetdataProcessor{
    
}

return 'modWebResourcesGetdataProcessor';