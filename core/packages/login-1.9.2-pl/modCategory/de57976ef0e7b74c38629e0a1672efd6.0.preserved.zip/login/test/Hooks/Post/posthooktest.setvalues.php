<?php
/**
 * @var LoginHooks $hook
 */
$hook->setValues(array(
  'fullname' => 'John Doe',
  'email' => 'john.doe@fake-emails.com',
));
return true;
