<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8ca5fd209fae3fa649eea1b30dfbb415',
      'native_key' => 'core',
      'filename' => 'modNamespace/24794248356ea8cd01593b619a69e3c7.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'c3a802aa534a306f1584ea27953b5fdd',
      'native_key' => 1,
      'filename' => 'modWorkspace/89d81cd29cec6cf2843a6edff665f176.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '221a8a8697e9c423c23362555bf82897',
      'native_key' => 1,
      'filename' => 'modTransportProvider/40bc69025157640ef6027c5bb859da27.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '07ae8158bf916d49f133f5d30ed0bcfa',
      'native_key' => 'topnav',
      'filename' => 'modMenu/bf6913dbb2fbe13b78442ce9cd2fcd3b.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f1e6fcb11110d111e74c1d1b7676c548',
      'native_key' => 'usernav',
      'filename' => 'modMenu/632c5e12d50b2a22088fc281f0c86eaf.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e4adc322353b0dfd56a615cc0819139a',
      'native_key' => 1,
      'filename' => 'modContentType/2e634511ae94d0041b845247f40d587f.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '903e7ec8a6ba87db177e429862a7cb9c',
      'native_key' => 2,
      'filename' => 'modContentType/7bc0f2d1e5978741cf0ab7ccd20c1625.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'd0b238d90237ae997934b8a846b6eb99',
      'native_key' => 3,
      'filename' => 'modContentType/7510533baffd29ebc288e9a2145d614b.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '2ae3a02ba1849d7891da4e276bfb114e',
      'native_key' => 4,
      'filename' => 'modContentType/2170a10d5c1e2a57d23eac24cd79ec89.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '133787c24ed48f5358ced8ce70a93f46',
      'native_key' => 5,
      'filename' => 'modContentType/4292e808d8346bafc8efad2d1039b4b4.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '18d243322c46cb83fc12748e250a9eb6',
      'native_key' => 6,
      'filename' => 'modContentType/3a8976ed8244771946eed93fa5c9ca1a.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '562e214ae4ed360d05040ca6d7eac7b8',
      'native_key' => 7,
      'filename' => 'modContentType/724e5178de2211da9e3a89b669ae030d.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '5544f7b4b9798099d7f30dd431b9fa88',
      'native_key' => 8,
      'filename' => 'modContentType/9f6e98d4ba99d2b320398a1fbb1ce147.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'fbd5422593494a5b803e0569e260c22e',
      'native_key' => NULL,
      'filename' => 'modClassMap/21cbdcab543d3a53cb190fd7bd5a2359.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6ba8ebbf2cd2e2d91ad6a17f8e10de59',
      'native_key' => NULL,
      'filename' => 'modClassMap/ce8bd31d924681bf668e5baaf8fd489e.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1f16a5484d8d7658872b55189ee42c55',
      'native_key' => NULL,
      'filename' => 'modClassMap/9fb2fc0ae7f107d63264539752228fd0.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e68efbf6b3e579d16291c2a3625e1ef8',
      'native_key' => NULL,
      'filename' => 'modClassMap/423a945687839af42ee88c3a8c8788f1.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'cdc2b07bddee17a11715f91d15d9bacc',
      'native_key' => NULL,
      'filename' => 'modClassMap/d87f690ab1fbc648ef8e18b811e44071.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4b6069fc66e74306d59792402da3c534',
      'native_key' => NULL,
      'filename' => 'modClassMap/c7f7bc35a41e15be9ada1d9e737e5b77.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'adf95aecb7900da29054e0cb6569682e',
      'native_key' => NULL,
      'filename' => 'modClassMap/b84a631e737bebdd53c51913543bd13d.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '83e430db07ada33235debb01a2062831',
      'native_key' => NULL,
      'filename' => 'modClassMap/ec953edfc103cd899d197842ae3ab46b.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '35ce26178e40b01d0e317208ade3c6c8',
      'native_key' => NULL,
      'filename' => 'modClassMap/263f3c9bd1cc966097e395e230ae8a8e.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a46d2646d1eeedefbe34bcf548d5363a',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/d2488d9145ca70d7d19ed023cc4d8767.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e03881e8a0695d21a2b8b41283280cb4',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/179ad84db784c2642c9d1cb640bed01d.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd986342d0bd58bbab11548e18c9f2722',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/502df096afbdbbd25c9a12801327fc20.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5e3aa74ef84fb134c4dc3fe31d2c1f8',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/923cc0e672f2f1d152ac04588c0f4324.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5bbf881d00ffd7d2d6216b15328e2a8',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/cbee65447bc48ac6cd3383256eeb461a.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17d3faf3647da6352fdcf97ccfcf2685',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/7716abdd458e95b701af6b1a8d2969e2.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6650f6590e29e3250504a0fba2458d93',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/14c697cbe79ebc1f8ea7ec6acafa02fa.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3584b8bfffcfb9fdffbceb0ecee2d882',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/d8ea43f1eb3854963d7663ae19bdd4b3.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '523678539c92189efbca308b29b1756b',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/33b075800deca57900058627b3e0478b.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa313d2cdda975e9be858d2d9a6f9fa6',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/954f938391f0c7f4fdba814fabef8c06.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db380d451985d41cd86a3fdb5d325309',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/c4d1d9585a15b2960b3c6c18419f3fbf.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '252d04895faa6c29d7c674367a251b70',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/6ff89728f80e1f5cc9675f9f5b5fb683.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b99928181b6363525a201556fd7104ed',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/fa332eab6891ea7f1a32ce80bd84d4bd.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '771b8d38ce8a5529ad9be1c4b7819b9d',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/bec6274ee708b223cacc82fe08daa8d5.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17350ae623502ee1d1382104baf121b6',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/6591e90d80acfa48a2df8c62cc45e2a1.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb9106025e48de4fdcb90d3964e0583b',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/c36ac0677f7d690c4c083f439fac6557.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7698ebe5a2d5c8ac56aa7067bcbc2e76',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/4cbdcfb6fbaf559cb3f5d872bdd14f10.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9599411b8d40c44ad42a2d33a45e3b4e',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/4bf24f2540293f46e8be4057d75832b2.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c06abccad88bd4595907b2ad4fb8f0c',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/afdf6d37352c10a633d570d712916a2b.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '24e3d9037e63e139c948d27bc3e95b93',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/36f3db95cfa3d9704501a45d0fdf98f7.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e155de125eb7e435525b97e299be7936',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/f3a03905cfb3038cb1d55474cf49fe29.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b6873b04d407fea9bf67b894137ca7d',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/7dfca0f2ee9a06b877143d695372bde5.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be348214efeebdff069aae09097f6b47',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/a20cdf9dd0f585b711a3596617687f72.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21ed3bb09026a28ac883bc0356d48436',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/09f9822b3cec895d44b85333edb70a6f.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d4314c27f780c068a6cfd6704a12782',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/0bfec55dd52e5daab9af4351f044775a.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4df569b7b6ddded5aa09e670aa8a11ee',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/ca4e6acebaf7b6adf61848a79bc783dd.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f80eca134e22776150c5a5387f96b67',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/d1415722831e48347edf02aa72100489.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f74a7756a68188204958a0cb733bcf7',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/b8e6ead5bfae2f6a0c7b8e5b18289b44.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66236cdb37c3a004782bfb45d0a1600c',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/c8cdbb0876bc8f6f0d45f67ef1cc51cb.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f496590f9e54f623a6d96098e7ff6e2',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/14b0f0b37e38337428f68dac0bbfdb99.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbec08493474ef4b4bf9e46585892547',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/7bc5b2d7f43c417b90ff3262824497bf.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1eb40fdcc116c2dae704b468be8302de',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/f395832897c0c4d4ce209b2504c8b73d.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca1be006a7185870d23ed24313d091b9',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/3090a7d6e57ba0706c1d574d0e492a68.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d233e7b58d5d72c5417362eef3ecc4e',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/ed6e21e2f9a2632566c2d04153c1e1e9.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '203a1bd730d8400d865c5ffc72398746',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/acdce535dafce4fdb577af4e0c427eb1.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f46141274721391e88827dbe47038519',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/103e3b458dd7be988bc7840c4853d0db.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53da3a364d68ba33caf9c5685dcc5660',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/05b0282232bc03807579bff380149877.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '680b366f757f323a3183db4436cd327a',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/6798c7b49fbfde6879720c8b117f8be6.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aee4b72b40a5946b9c6a71a4b90b13cf',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/8c6964d1afd457dd124a7d9db611d9d7.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '449bf690547757cfd9d037ae91218f58',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/87c0e2dd8abe1f790cb16e34da614ca7.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '000121f1f21cb03f1bcf26f2e53938a3',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/309a7ce89fe30589998aed3ae870c79d.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87ab982fb795f7c342575fa7ee448f23',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/a6f18c50ce00ec56208120dcc6205696.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf19f730ffce29dca1c89d2e35a3a9cb',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/ff031d3c97eda40f224c655ad3f24b43.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '351ac5ed44589d595c64dad3d48a03b5',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/60e1dc9acab9c13b4ec9d4264c94b243.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbfb81146a9ff2de88b64ac6840fca7a',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/1a1a95b8a73ea4d7ff32587226cd4e92.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6042759a33ef3cca735b4e2bd1a3eec9',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/425b27e02838caf0cc4ad0d6cc0f9de9.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d70346745632681fde2c15ff4ae0e5b',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/7180d23f21848b18bb3a3a1ad3a2769d.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11b911ff6e192839e45dd717a7279d3d',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/7763d949ba7ec3a6935c2787b0cd7aa4.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '493be00fd121917116449bb84def86b1',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/bad43659ff4c73600850ae9bfbd67efe.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75711581bfe0f103e2cf1a5f9aec832e',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/f3eda44d5b089325307eaec45972c7f9.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca54c0e7569f6e4934df760600fe76ef',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/99b523ea11f1b23b88ba8c12dad0d1f0.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '792a43a79f771544d21d63cf2394bdca',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/52aaaf008d50b84aede3abfe145fe094.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63aff9bdcbcb867761ebc633f39554cf',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/12ba81fa7a69cf262b8b6c105bbbd833.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5c7f21aa3789541ef30fd0ebd559859',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/8e2773fb8a2623b684953df7d052d7bd.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '093c936d3f8f6264bdd8557ba75c84a6',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/989a211ffd4c5a810605008fa999da54.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c622f17eb4abf25153e478ccd12ef2d3',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/c399b3e8c101d4f870aeaf5766b099ff.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc3f18f527ba55cde0ffb6e751523e76',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/8bfa4b06decafe8d13d91f01001d4f53.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13426933461b8ee6a3bf514fdf842784',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/9c9452a2651706d7ad4cf7e5a838ec63.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc55a3481c1a8334c8a177ed502c6d8c',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/572a32d5e0b4c902af412f2f11849e8c.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6aa2f21c3638809b83458f857de4b1b',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/56f2e0533a3c3d942c895546883e3bc3.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9aae11ecdd34dbad5da2339bfea6fb7c',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/8712a4caa0338fa3e7e37a6dfe105289.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a747dfd3d2b8bed60f1f1a9e60be4540',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/0de5a0f732cb4e67e6adc1dae81e18a3.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9f2059dc1d4d79d1455238837496ee3',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/85231464b1b040346e630fb7febf00cb.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86cd1c4d59bbb73489ff05de9c60ed7a',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/94bbfbb3c72acf73a4d50a36521c3975.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61bdc466414cd9be7845f7f2ca7cd8c5',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/ad3a7b8c886eb2cae0b2bb6be7e826f5.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33ccf0b419f093cff965f73275804d4f',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/810a7a8052afe32e2f451eba40dab1d1.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c0cf3d16526c9ac4bb47bfacde8450e',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/c858ccb063516b96c9561552a668fb20.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a06d678690e700bc18451b39bdcd30e',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/d26a33322c565187c3355ac796b8d517.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d2a8d42de1954a3f345bbe3fabf2f30',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/2116672cdc9c35b678f5fe5288871cfb.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15108e5a8fdb093f82d8b1c4dc97c5cb',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/dc11448fe92f357f4e1776d94c285cdc.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3140163fa371dc5ddffeac7b6429537',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/68eebd416385cb3b1684c3bfdd93161b.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af11db1e333f413f700eda96f0e2fc8d',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/d8eb8a2b6112f5f6ad79c46362f50bdf.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e7e4bb5974002f3fc07db307c136d87',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/d8f33868af751d31e5bce8ede6a4ae62.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fffc2e6e4c1a756ff35396be425bb1f',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/0029cada8c4218afff3ffeeff89268e2.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78cff561a1ec775049ad7973cbd8e73e',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/0266b0751152f82c37df51991bced78c.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '112a5ed4c5be7b90d8f0259712ac238e',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/f2362c404e5f7def691c2f9b8c823256.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97364c40a8227d0d9f480389b9678807',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/f82de90679c52651680aa96d012dd3a5.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b55455db6d9f904345edf7756ab03941',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/1ae318ceca3ccaf01dff7554490f4344.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f86582703627e09c2ce683b347717c0',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/5dfbf26f46c8ef31b1af00dba26edc14.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86090988bbc05e6e3a10ef4a4de75c0d',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/8b609cbc06ed43ff9f5e42d9a10f87fb.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18ac2ebd8399bcf30530d944567c37aa',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/de24391a212f329c429b7fc14401df8d.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5e78588be2c62639929da3b79fb5b8d',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/0efc0f6b51f0366b74cf0f680fa09767.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99bfda4b46093af670e34f7225306765',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/5478ff1d7879d9bf4ed45bfb4782d9b6.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c361e9784f29c66afc9811af962d3965',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/ea1a17a8ffcd22bdd3076d9aa25c3be3.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f31855558ca7a4299b88b1f73c364fff',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/ad66992d9361e041f14fbf171412285d.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '046f67966f1e2043a107bc673529f8cc',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/39f369313655346fd0edac5b75df2fc0.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb2bb0723e8a699bfaf0e2ee3a782bf5',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/bcf599859f43caff1a8893470f3af655.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75b897d1e70026ed438397c5a36881bd',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/8bc63a28cf27b6577552501c942e7362.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64d873e21b03970e66a256e05c7c5de2',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/048cbca5ea488d69c9251a0bb84e11b9.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f4174e814cb861cc605597a9f148b00',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/f12ced004606986a8ba2705cbf1af7a3.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '943ce528faa7b9ef78feb86f2ae3dd53',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/a113572345173f2264546666565de5e3.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bad43cbf1d82f48825671ec59ad80dd2',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/b2c0d1a32eb748ee91c66def0f5e2bd9.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a415ec4641bbfba300653ac46e5da469',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/1b1b5aac04c27c6baf0b34c05f81d9d1.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dd8260186cc78e081421068d5855c06a',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/f6b768784509a2afd5a099368749346c.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3dda2771cb237a33950c6d63e917a0ee',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/4b5f2e0c6b8f72bd6b70103a403a2c4a.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9d0a133567d30e3e6614c675c274edf',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/0557dc227a85360fe5a94fb593b92e52.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f593834c47a74560622b465166c068f',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/870f1d2a015d43d6c03790d1a1a9ff2c.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12c48d9ddd4d6c1cd8b840a6fa75905d',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/c1dbbc4b0c76b5a33b66d9b7f4992460.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2d5e4cefb67cfa91d8bae076f7e9672',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/36274d7c7975ea785b5a9eb23bc812ce.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2106190c94bff173c678b6275ad5a0f4',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/e994ba21fd3da63f35cc19b7cb9dbe15.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f159171b60aca0a0440c979e305515e0',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/75fd504d5dcc6a39584c626b05490697.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5f21a53acf679da0c4919fd9aaadf93',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/7fc8525b639fe7a46ec9447bd284412d.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1d780601502d5a76d54ce96517ef820',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/5fe6ba32a9fe96d05a6e67205b3ffa99.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3b4b74384aa27fc5a1854ae3a696860',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/abe49a7023203571ca9784c118c6de62.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '632c85fac969fea5678ea1b2f114e834',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/eae4f5d07ed707027c1b53ece2786c71.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eeb2b4083286f2cea7203cd26ab28988',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/650ee2b1c5d0d125d53670c0bb83e4ff.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a49edc63ccf2600b9c862d638ff0d5d7',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/bcdf614d049c3f9852ccc7b88d53496e.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdec20abab37da71d16ec7c886c032c4',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/fce36a2e83bd46cd066ca08e7152e0b4.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc1d9ebff83ce03f4126f96d5b505370',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/931b905a74909a6c5358df041cc5be26.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9fa232e178532d401bf956b9f58a2832',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/5c83111bc5f0036695b7c15a9dcb2f8d.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ffe0ba7fae2ed6095b555817eb51f5f',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/d4600e0f6ab20c63a2ad2b9ce86c19fe.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60ee8baf991bdea74471ce688f1f4e44',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/60def48b3568e903c4ecb8c99a2515a3.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '929e8cffb5e41f7d0b1572c37c7cdb9b',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/6c417520f46fb5118a497d0c4ff3b220.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '560d29e2da91da9fcb6e5ba3d8fef3a1',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/8cfa1e704b2c8bf18c920fd55f74ba2f.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35ef2f376c240563c31743f61e31fbe2',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/2246cc51139e3492d47e664c04b055b7.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6b4fc7e9239860cab65e0ce438e7616',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/34f0a1e27c9219894eab3daecf5b9020.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b5f22ac752555778cbd4f1ac1f5b171b',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/4a72039ce0d05a8291c6493ac3f15cc2.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b60c50371348dc0f4ae1a077b24bb2fa',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/baeeaea049d604b4acdf5b9931c14972.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbca196c61c197eb7621856527ee42bb',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/d37402225145e61ee4f257174a1ee449.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8a86c15a3ec8aed95043cb946694c1d',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/0f487b95cad962c75dfe0d7e7bb4d490.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e1254f8a2093580c510a130e8c490c3',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/a50702fbcaed1b5d099a7f0af6334f23.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98b03943b777f40039d1ea4c8642059f',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/bcbf981ee00a0135cc6c00cc677f2466.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebee98d9e54f4f1d8dc26ff9b7cb020c',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/69b3250db0f9939b72c00f8f698a5817.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '297b5a111f9d554ad7103f9b75cd30a6',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/de87b9e93b3ef7ea41c6a642c4b3a792.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd299f050c24fcba970d0eb26b59bd148',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/ad5fd1f53ed35206a1cfd4db940453bc.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73ca52d7b4908bd31024d19fc6664436',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/996c137fdb5f767eb19b1dcd5717b49d.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b35633fd8e406f02da139e8d1fef8867',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/d918fb84b50b5364764a3fc39f3d2a7a.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf65cda931804fbb76b3cae2f71ebe59',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/6fe35a88fc548b707886e47fac043a83.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '844f122ac78397403b3d3bc0d25a2eb0',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/1c841efc0573161d81b506d7e6aeedde.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71cfa671c0997af47fadb330026b1702',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/bad64d4559e2fd36ff938d8c9524c218.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e478a17342cec529ddfa5071bf4a1a6c',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/a4bdbcf6c376d8a1aa8fa1724e835006.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29cce9dcb97df93597fcd42c655f8a67',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/34a44308d36add62215864cb5eb5aaf8.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'beb5d82e376f8b909c647f9f10eae438',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/bcfe1a56d78088f6ebbf4e03904a3f22.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cc19c6ef3e27a6b4537517bb3e022d7',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/02530923bf3bc103c0ef28c7fdc70a85.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0878bf845d571021f8fd3351a0ac0e9',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/a179148d0c2b01b828d5e78f21f09be6.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3554a21efd8e64bb07edc85d235647ff',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/f64c247a8d0a878d36332cb5542e4420.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba25d159e3b7887bb3c083a017ef54bf',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/e89780594b43e7346d2ad6a8590851ab.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fe963d965f317c50481b2edebc6c7f1',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/902065a67a757eb8148426a48f6ef9e0.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a040625c66fca97797ea9bd088b9eb0',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/c11ebf8238e3d7e0a89c800eec233f14.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a16bf749c5e615fe5e07f8aa094013cf',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/4dfa8fe4d2f912f52f66dd4abf5c558d.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '118572aa650ff2f8c5ffbdc3d6499353',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/62cf0d45bcf79bc010d9458567af36a2.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1941bcc49d91bc52e5935c7eb3ebaa35',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/116809697550f0c6ee6208fc70c49d27.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b383b029faa84c66c85f8edfc9d7bbe',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/b57b24279ae36b333feac7a12ed1423e.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef128754307e7d52094877ba571565a1',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/fab70f1bb819ee2e0b8032326ac80e5e.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3aaf604e4240b028c5cb4a951792eb0',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/f1363b4ca16c4761e6e70f044159d20a.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e824cdc2f2f80dc868540e00c5b778d',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/fb2bfef52644386c24e30c58dde22a51.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49ffe16b0de891b82563563cb7c6b857',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/84eb7e7b59d0967142066e8e8f0adfd5.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b75fb76b159354b12d691f89f517d7b3',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/9d8151d79d8818d55732788de85298a5.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f484ee97cdcf4fa8351c76b150a23ba',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/d874d703b975a7a581e5a18d49174138.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fc325398f0102a50e5eb331483a90f6',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/b8e2a7c3dcdac9d2f3df2d118141ecd6.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ece62c592f50e589ffb04da485d2877d',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/8551c7460445cd2ea7ffe689fee9c223.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f875d907d1ca8cf0653ac76e690b12e8',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/aecf8dfeb8a0a83941e601b9b63699f2.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21657edacbfeda81a6c3a72e2dac3d96',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/9ba0a783d345b26839f2ce5f64e2c4a0.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f540b4a0ab054a54aa05d824b464be8',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/a00748122a142ce327b7e4bc4840fa65.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27fcf1f37b1b8f7e864923f38a3e63cc',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/23000e764f5195c32f857c10650c282d.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33b1085f19a218533b58f96818cca076',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/9300e7d0b77f9b071d06bb50bb440617.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f8216b5e88125e28be122fddd54441d',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/fd5d5a46b96e383c1c1e77bc0d61dbce.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c0434b494da35e3835ccc4a4e4e137a',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/ee8f8367582768f5f467bacb8d9f27f0.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8279949619899141d8787aaa719227ba',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/a665c497955dc1dcee7f2887039d9ade.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66a1de98449343d473c5a92958588644',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/73f2a06741d2a1320853419edb2eedf2.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e09b1e8ee8622fabbf23b8e5d941928',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/1a09289b85c02b9b0966225e96bd228c.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '833ead80916fad4b496b4cbecfb8b5ec',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/720fe26931fdb3186a14f78ffbda9f33.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5270a99f0aff324cb8bdcb1bf1f5602e',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/1b9f275bc9a64f56bff22aec3fc6fdeb.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e0eb229c35144c0f405da2ee094a0e1',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/5776cfd51012f2bf4fa2335b63734e17.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb0fea19df37c59d33af45612122e0d1',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/fb624f83fe57f97989d7a36aaa552431.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea5644a95a8f855f9283ff6ce6799838',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/704ae01318010e8fa46f2fb155bfb9c1.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a74ca4f9863293c6cacd6db2833785c',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/cb796b8017d23370289b6e50303769a2.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd22b83f05f4ff0093a1b3942aa2919b5',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/2b340254511ea0e52efcac87f7af22c8.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '922f5b50d398e5a63eef03432e2382be',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/0f5b33b0d7d0dccee8b3e9e8f8e86323.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83d4e2f7b4946921977811dafeff9380',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/57df2600112830e420934139596c76fa.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8bbcb4b87283a4814ffc07c221d77dcc',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/864211ed8151392da4a3721b1e9cc362.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aaed9409df185fafb560dd3b01dce653',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/d004191a2c2335d166e71dcc81f60c4d.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f58fad64be2d7859544cccddaccd3d29',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/81c52508205817a86f6fb03300b7d8d6.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'adf97fa26de3ec5e8a971925fee47f1d',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/7a7457ebff3209bbe64e7b6dae0d944e.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad1c12b93e5512c7683dfd094b6e2d8e',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/55618a87190a440e7f6886e432bc941a.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd847bb2040a47b2c0011dfcdab03cc6b',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/fe0d5142137e9de1fa712830a2967677.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e58c82663e246f79924a5d99781c984c',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/d33fbdd4925e0d14e4884eeab0971e4c.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf3739cb9c86adffe5a9d6a120b9ab3b',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/236dedbfac75d9ad7418613d101b9aac.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91c095f0ab92b03995fb2cc2d96e6e75',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/7c8b7c28d730a69b8163757a26e92d9f.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e1b7ab517c3a87c8873e93bd76b7839',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/1abedd5e83e10758c0ef4d8df1ede398.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '508547c717ee204c30f6ae01129f4dd8',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/b462bd35f2b0e2391ee705296be6806f.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8637ccfc88f0c1a5ea5a200ac151ad7d',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/090d1c072f4adc5efbc292fa58f4c847.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '584b04f9027bd1ffcd06b3c05f2377be',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/d761b6b40f0cb149402ca82493bf6154.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7fcf6687943170f64cfab4e1d057954e',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/b12b056bd62f4ca587ddb4937fa58d7a.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97507f8d995bd851c1fe639c5e5150b4',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/a7476fef121f20ae115ce11b185cc603.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27ab2a81bef358782782eb6c9677f1b5',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/c3742325e963b217b3df8ac053ca95da.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72de1f918d76cacd28076cb5caa7591f',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/d2701a114ce166b1ca00660d5fb65833.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e6315028db33ddb204349dd21563734',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/6a1076c1b4c23ce4ad671d87508f397c.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20702084aa54d72c1334ac906078edb3',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/3a0590d191bda3b4169a11d46e1962ee.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ee6acb3e8a90603f95d48769bd1fdad',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/1950bc198a8ba61f09556e61bc1998c0.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f2eb97810559c77cc6d6c717ad90388',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/4f86b9c73c4ae493417a99afd02b94bd.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f973a563a23176e7692bd00abed1f3ec',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/6f929995795c0831e56e71919ca3ae7b.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7c0145cb41540abedc8b52742ce17bd',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/41f6724c33295c640c8bb355d91f75f1.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c3b204be2a0a9026ec2497858d10334',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/b9afbd25d1254b7c25d8c83aeb62e425.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1c13064fd536f3a972af0b628e4c052',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/3ad4715333525126fb2f8788443f4ed0.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46f1de3afce04a4a5de02281ababba25',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/cba7fe04f9d64388f86062394070b4dd.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6f1ccc0bce3ee7bc5b83cc7c206345a',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/71ac88b4e916cf4778c61c568d368547.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e5873a0086a109c5e054829933fbaf1',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/9fb4be83e2357670a78307feeff41aa7.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28114e601b969fed8e2520c681ab7d78',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/ac1862cfd78a6398f692a57ee7858aa0.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a15eb6b5533ef8823af2d70262572d0',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/b4e19d110f7e6ec675c0400f94bf39ee.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30ee1e03d546df260e522523bfee3f8c',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/35a3cace1eae5c5a764263e030dfa3f1.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a0f2cdb6970509e294715a8ab9028af',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/61851937ffa719b30b5f2ed6abe62af3.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3b796c28b3fdfc6955666a56af4ad3d',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/255d0f9db5835c1203b3cdab624ef329.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b75d048804cd9c44687f00250f28bebd',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/aa1bf12a64afda2d126a125a7b4d3541.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7968dc813d00a52b14d9d5d6725a8c2',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/343481452c8429ea5910e3919adf677b.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3ae575d9720edf84b6a99826fa7f96d',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/724e03959f1c21d4d04c304771149855.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '791ff8592321b67741d933db85c3b65c',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/6d56e48c9d9a92c492c3c024f33d2555.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5539621cb8e0acaad0fe3d738b43187',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/688531a3bc83c63fde49ece0b193c9c0.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67bb88f1b40c93734e899c83522fef0e',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/750938b8f6dad37e9215d0944b06c605.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34a197fa418c32fd4ff70cc2a6ada67a',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/809bc4ce4d856fc586387b28710dc7c6.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0581914aa79230a44136b9bc45fb2bf5',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/3d1a08288f668a871f821f9c8f153ddf.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b075998e5697530973213a59fbb1e081',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/c9c3f9be3eb5223171caddf8b253729b.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4071ac869a80206c06b9df52166de8a8',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/d2102f69abf6e2e5792bb1f8ef79d6f6.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be46dd8992284991f31b21e525964fae',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/d4b8ce76e2a1919c782a12ba241f04b6.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f38322bccfb2c60db16c9ab2b0ccabb',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/76c41ace76bdd15b4f1c262b33972605.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2489c538a7aca40f53ad5f5f8101272',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/4770fcc03b89821ba1b230445f3371cb.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b50eb5c572ac0f558d02c86f293ca2c3',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/170d3f375a24e7a162dbc2f299e4cbbe.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '325e8147c21c04179ed31c92ab8d14d1',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/a4bc11e91c155effee3715fbc3e2c3af.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '173c2f3964ef8ee9f1630310de52be91',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/6c8a74bd6454871e245860841555e603.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '698256819d315e08bccb1b16f579ddba',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/66d662ce5bf310e5e1441d738fdc15de.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91546803656838abc282aa35f0e6aad9',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/0562dbd39a0035bc4debed0fba0ccf6a.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73bab06ef70c5f62c069fbc31d0618bb',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/50cb75ca46992e65ea4031dcdfb23962.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcff31de7ffcfca4b952232676066889',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/6562dd40b2953249442326254528e899.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33b0e4a4a026348b66eb35fc67d6cf85',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/7520c26f09cfd69a00618c2860d27f04.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9fef5262b45d4f42c184cb8daef75c6',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/f5691003cbcb6b2429c8d202d88045fa.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec9e79af1e60e10015c60b5065a58a40',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/84c1b118c8272075c430176404608844.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '810d2aa1296d086c5fd7f1251e9f3ea8',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/efa8bf127d2d1d91c1d8136bfa79f1f9.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ad663fc5351791dcb0649a540c032f4',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/da850672048258206471268058390dc5.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b84bd98f9877ed0c295976ebe2c350e',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/4bc15caaa408d7ec4584fc14c03eb95b.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5f1c3a8a55dc93347fd06adf91c659b',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/356d6449fbb4de5096bca4566bb90c38.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd07613494a8fcf44a5cb366f87aa7a5f',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/660d3e752620a2cbcdbeb71cd4b4c6c9.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c384454c450b2115ade1ed26c3759b3a',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/a7abfee92fc49656faf88d6d9fbd2107.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c84c93e64bb320679dfbb935a544a417',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/ff82e700fed56ce84895a1896f90df36.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ff8ae7fa3dfe9f08e5740dee46c1eda',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/4353f005c6cee0ea650f20899a702a8f.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '403f8c807cd2450b565be17e6386a0b0',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/c0c98dc34ac95a7e81361f9b762b4166.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0903c3d11428c4b4ece6bf5b34d2a7c0',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/50d77d8963ae55e70676cadd0bc3bfe2.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f210850e52e9aef0ca9c322ac2405f55',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/e404adda1b2e1aaad089fe2a24a9d670.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba0b1173f26c6501c573dca29535effb',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/3ffd5b9e4bb35cb3b38eb25c39f55be7.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d14af2e3ebd4527638ba15f7a6ab158',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/3da8e05179b3c616cca5b6ab5eda7c15.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07232def0072c1af88f9a695eca7bd90',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/e3ea2a6aa00ee49216eff622ff76c844.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88533257329be1caebe2f2668e1b0a19',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/8a1595ba313f8783115080bd5f6f1733.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa38e6eb47817066e0db38282f7ec052',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/c4cc20dc2c45e2d244adbce57abfb47b.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b70225f7bbd7eeb47074bb777af9288',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/418ca06b5f880dab3b42a479458b54e3.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5738afefd2c318d4f341d203301f18b',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/d83b5bb9b848c662c56733673ff54194.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce9c91f77e0a9bcf1149aefcda09db0c',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/6d50b71f22b1db75d5250e7c2110f1f6.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eaa4ce32f506cc9863febdff1450b08d',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/5db750830fa076dbc46e5df78043ab46.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e21f666a02869f088bf0b0a5318e6d8',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/05c199c33069bdb4d9ff1f70cd8b2306.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1927d487322c0142a4251bfa3ea9c647',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/a6aec980774781e14a7f1be24a87e655.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a2accc9b802ce14bd118ebc46e6d762',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/c7696cfb2440182d7d7acd7356542ab6.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec69a98dd88bd3b93d5a845405f302e8',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/8e64f16e8286a9fc8888ae1ca8ca3141.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9225c70a3c784bfcafd8fd57ff7fa829',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/cda1669438f8f67e477c13ffc7f8c86f.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6330de3dd3710b1654f1331efaf38ee',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/b140ccbf821811ce2df4275e69876acb.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab4dcba316dc2dcd24d26e6b7c701e34',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/91a8b0dcc34430414d086ed0bee3b13b.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc8b9fb757c89696658654816111038f',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/052f66b465d664414933273f778dad1f.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97eb5993d04e9e521c04d36274d99e21',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/60a433b11093d3e0df7626460adcf121.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a24f2c7206ba939e42e731ea31d2cae1',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/939994932f6c9e141ea01953ff07e556.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eea9f54f2642027548f991c6bb928c1',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/801fcc1dfe12b6630065acffa6be2b9f.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5b0bda3141ce5d5e46a78aa769abe8f',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/99335cf5c58ed67a2fb38bf3355f30c5.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d41f884266e6f762f0666fdfcf4de17',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/b794541d39bf35b0d636697db1c28b3e.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8259eb407ae7909ec0624add90b2e449',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/06a3a97689444c0f88adf5e5a10237df.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '451e1afe3381b4e8891bf9099978c013',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/dde789e9f0517bf22d265e55b44a82db.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20070aec76e019b93f2f14a815e1a6e8',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/6650434dd54a164c412bce8da6a43013.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a63e563560a95da87b210bb79a64efe',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/c14aaefe56222fd016c3f5a1dbd75fd9.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f03362d0b9422754050c16706f7bfd3f',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/005f829829a1b23eeec4bf5e4db2b793.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f00118d3d54c5eda034d95527231639a',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/27618ae51880b5fe5f3aa59df050344e.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e81930272c1078605e990e5b406875c2',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/1244fb4a92a03bddaedf5a017de50bd1.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ff4c5b6753a91166952a1686dd33bbf',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/9d80328c14b16c8cc99db09fdbe948f7.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a70172cbfd5685ac75479a6ee99f9c9',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/b54c04cd42f4bd63cbd8c3e08242632d.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10a0fb46f4064633479ec66f0eb12831',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/6dfb6f82760a74dc91f2c3a468046166.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37168d03545481e35a06cf1bb6cd8a9c',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/5d9b42dfaffc559a2b34af950c42c6a3.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94e69e8d0ff227967725f08020910cdc',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/249f98ae51e6b9daf50f2c953c77631b.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cf2212d95e9a76870f72a22f1345c98',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/b5c120698cfeca38835ff79be6daa479.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a308b8f122630881ed6abdd6fbb8ff5',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/5f7fe3129d8905e0a76d05b8e89dd57b.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcc47990e8d0d9ad851653ca74f5dee1',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/fb79896c2576dc8f09bc223c20fa2b89.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '954bbcb5fa856b673f11bf67461b8373',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/b6775eac68b2e598ca59f9d737376e13.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab85dfb650fc4bb2b6a0f16190e2fd30',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/2ff6197c7ef0a0ad04ab1df4a5d2dec7.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a7346dcfef7c3412bb4ad5fab1a8c3e',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/327c2295ae1efbde22b8deb3ea19c8a5.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2280e5096105424aaeabf4343699c0b6',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/8710733587efafa92d7847d6b13d8adf.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2809388377c344835cd9f62bbe635235',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/b76c4bf839e2ef00fdf8fee2e2196b9b.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '974a06cb4bf93803e5a884fab1abc5af',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/db22a3a8f8681e5d341ee35ffe5ed92a.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6be5f497fab52b2cd24535289e81802a',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/887ef625eaddf591806f7fe0d950934e.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c842f533dda01382ec691516496c14c4',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/b967cc06f7a00fd744b8c1c0bcc15a5a.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8af82ae3f66efb02fc1a97dd1707a364',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/3f781af346d320bf25978f01f51f2518.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5b579fc55648b0bdab8ff91ed68ee04',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/a2718674e27882b553cb951544b3e010.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c4f420767cd317885a3bff832d0704c',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/2c0fdbb972cdffae32dfb7be6c6dedaa.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9af9e490cc5837252606c05f2b2e24d',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/40e68091f62f5c596fd91f6d2f0bc587.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b8bfeb233b44848d7dd6bbe4f05345b',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/0918438d4891aea27cd8411f51e86f77.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd997a89a16fa7f5e7c0b10a8ddaa9020',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/1b3fa92b0973406e41d928a3c0571b5f.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f939384cd967b032920e535a1205b3e',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/942aa56de08e1f65afd7cf19d7e05509.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45773c8cf5bbbf2d70ccf4972cb67e72',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/a0d0fb67e74bd042ee283af20f0a8a36.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d9b02c5ef3fcaaf80efab8c49c4b6a7',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/188c68c7b70740dc9e3e569b02f150aa.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f003396380339282eaf267c83261d2f2',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/77f02cc437616e6c6dd09932bd93378c.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5ce3b818aef3e1d83fe9e7e8f757c1a',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/cb5cadb8d7b5c99a2dc65c1f45f2bad1.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69f71c12e219b6f219042def7409b1f1',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/8fd71ddb2098eb547d39df04c4425468.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '127db1c886e3d58a8b9c93e712ef300f',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/733f48c89661a47ead047ceeb8b2ba24.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '058729f2193f2a0eb9de7b5a8aeed075',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/a1b41c61fa39fada1abbcc327937bb6b.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8d9cedfa8e774fce7645f30f9fbefab',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/1616b6fb5cb26722d9bb22f2166d7ce5.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd3c3527be5beb222ce0dc2bf7fa21f3',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/366df6c7241fc7dd841ba4c4dae759a4.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7a650a9cb8f2a6fc7ee223ca5f40795',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/cb1f568ff9691200c8fe684fbad36ed3.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5a5acd3cfc25e21db4873dc3f913c57',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/2599d46566c9663cd8c70f541616175c.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '079b9c6752f9023e67927087a35815e2',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/0295b0ba6790651ca6d650e62f7cbd1e.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '009c667dff0847ecc47e493cc9d126b1',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/aa80d4f063a034be84fcce6d4a87c9e1.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f0e865bd4284c30eaf9687ca0009e96',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/986919704c25b23e7f931fcc3eb9956a.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7c836cc4246f047f902fd7642be4db7',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/09fa1d50a4c8389296ea5819d4bca859.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd21dbc6507a93b8c8a5a2cd8f779192',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/53278b7f3509f5754e5c3ed4a24978af.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e20b820de09ce0088fc39b1f265b66f',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/e598bf3344c6d29f8d723de17888bbf2.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0d2ea8d82ed98834a9932da07c56561',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/ae68a30110d3a77338f7a857e4e2345a.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5dfab6c5dc6e26a8144a4326964cd101',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/4b35bea299c87bad5182406db948fcb5.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81aed887793191884f0a5fdd3c391e2d',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/7d652fa9ed959262f8ac7097e79d2f0c.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d6544611224ceb5a3dda89a207629d1',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/bd3a6ac37ad2c234531574667154e264.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15d7eb7b600db9e98ba3466c553c7517',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/c0a06f575258f23d98907bcd58508c25.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e5b584ee1fe11550c5a522ed279cbef',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/484a4625b89599dac5dc4e0af20a013d.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09ae9b704c98b74f8bb3ec3c34b6971a',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/49841ebf805933368a32746712fe3340.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1dbb75a11549d28fb5fbcc2578439190',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/bbd458f4b63aa1b078e6350057c913eb.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e2004803eabf1006672cfc0a450979b',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/5d4f95edb525b2ea4214d0b88edfaff6.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd2f61aab609fc108696886fe04972a2',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/98a936560ae9c8d9d6f28de6a19ee37f.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '703262b1f783bd6c4f01de9869df51b3',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/f642552f12f5ca8bafeaeb9c320b6299.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f40f63be8f1fe4e7450f26eb18307492',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/417b1837ef135da2cef9a14c0ae8da73.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '224f2abb91f0c729e7f0f1eab299fa2b',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/d7b29c3c18a3798af509c2c6f420286a.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a866de824280853f39ecb6716a5cc314',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/ac8cea3f935aa7419ff534193263756f.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3eb220a03a3d26d62f3fe568c336a9cb',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/fb95b125fa0425a888a40c01bed77f32.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c002e546236a2c016ed3c7ab2d50b8e4',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/1d7d0dc20c026bd51de991fe411b5f54.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdd7db78092d1f6ae75b78fe7353d360',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/e5ee422ea619d6f120cd2e58e32dbda3.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa8e141889e6ff8bc11c32d6f4a7d562',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/b150f26e5bd0f3881d8e61e5a6092492.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8692b6b1dfbfabb58eae7317400a725f',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/b53fec3e082c071b449d5ea09a37959b.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c63b89f7f3fa2f4b3143bb71d4f519f8',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/80b34a1048638c250285a3e2e26bc862.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1076c547930d66c4e5a9ee44a12966e8',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/6c5702847f17a5d76dd3af5cf392735e.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f18b9bb0b66debdbfc9aa4c09f79bc7a',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/51e78c14935f280f8904b15b26adeefb.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25bf36f0ce03ef31783ed0d01048e1c5',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/171f6aa695daf958d80e6cde020718c8.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c63299ebb716b70fb8e0c51c2bbd72c',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/dcf349a3ff603833438d6d5f846df553.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6711fb974c275b7ea26f8941e1e659b',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/6d13717efb705cae0ca9997d81715d74.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '703b1af4e8046345c80b0d556b97f693',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/2a138fdd034ac434165f2843c6475337.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f8a1c13957ba4bb8ccebd5c947379f4',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/1e45c06f0980fe149f509dc58fcb18a8.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8076b2ed2ed397fb1b6bc1313e2e2665',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/7decda1ceeae041b66073b531516e764.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff5eed9c3bc63e36267178ca31c87e75',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/071d136e912c8dcb8335dbfab21c8bb6.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '070332845bdc20ceff2d7f247281d62a',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/d9279c0f65843566cc1fb40e2b27ccee.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75d445520d6d02382dde4aa268156f3d',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/8ec26778db34423434f9d14f3e8af06b.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82d817c88ffd8fb81672d67cd951effb',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/adc8f5103c2fd4e3d20f92488f8881b1.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f5c3f87d3301a0fa744d46933828979',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/54c041917dac649c7b53df40c13f5711.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '466142c1885746eee693d42169205dee',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/6904a145606bebeb4ab6acb6ae35df26.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fe69b682d29d11e548c9ef16abac84c',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/c5431925dd6818321e6d9c9392fd4d6a.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0a37f8561ef785b8502857d98053986',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/c1baaef45a6c1ee7856c201ee3a76dbe.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c77984a6d46dab0c415e253318af0cfa',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/6882e593a4b4a457a9ac3e4b1f612fbe.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6fd239b10faca968972febbf85a745f',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/1f2c9a4c083cd9168986c1f87d9ebd84.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e114b8092a7afd2c7aebfd2d1deda381',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/79799db0cf92e8a5fbb0eb06fea0d002.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c0c532a23fbdb7bfe8ba6fb34aeb071',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/f207f86d32a4987fa683e711c915f9aa.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2f8d1a03b52774147467e39c5b2d786',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/752934e7c82899d6d66fc57d50caaa3c.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dac3a28c8ee84b44a7828d8fb6272179',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/b23ba69b6095760a69cbcd5c70d968bf.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e4cf4a5a98ac3981f10e0b0b59f547b',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/4e5536da611d03100120b65d2df6bdac.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3e726c5b256014603ca7d5549b66f37',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/1232dcbb92226ead9e09c5694c9d3084.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1be62a0ae091c32dc24fe1aa93b75c2',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/2940c13c0a8d81d9639919e7844682d1.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90425cbbb8fcbb45af4af30eacae83b5',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/d5587b26f93d6291d9d1b3565393185a.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2066b71e9849930de68339817892734',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/dc90caf804bfcaf64a22f14d6ea5cb70.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1570d86b4a25c7e10eb103356876a74d',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/43c6a54a811929e8fe759b75bd482307.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec225e39c810ddf86cadb834b54ca5fd',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/6e1b4f2a0df90b2719164657b105d142.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '724afd2a85b2c3f02cee81f2c04666fa',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/f8caa352b5b1ac44984decb12e2fb0d9.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2419efd0c99e736b9b47c6fbf9921a2f',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/5699aa07406d40d31c2a164362c3325c.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75fccbf9de4da4086d80c3f27a3f8ef9',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/91f194f843d447982c04e68e1f2f2702.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7b3703e46a6c4033d67e2ca6cf71768',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/f3b415192ff613ea2636ff6b27febe85.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c312b400828354022e0edfb97f3802d',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/9ccba9f3ac46097b707851c336988cea.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03f3d85f8ec422a02316c06be9b90ac9',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/3d82be79f4203baead00fde7cb4b199e.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '987e937f8c0394a1245d3381098a865b',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/435eaf25e00660334979aee4b7eefe55.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '290ec43466e2e5ffccd6a1850a2b6749',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/2ca11de5db4d921ae76c361eff718686.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef7e10336701295415f454da110ecd92',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/61b41d0f3ae7b2df680f552df4a83995.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3e118deacbded4c3615f42d489b630a',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/9b4bb5ee68658436bc00b6a55ff9c563.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6c36dec4814c6b28ed3b679e0ceae61',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/5f6177a4e631c82e1af975decacca6af.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e43e7061584a91e4124eab3bf68727a0',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/34b34d579cfbe6fbaab0e4fbd40256d4.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db372a9dc898b05b5ce4ef1b0a594a34',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/e4609cd10ee407324cc9f4a896f5dc69.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1113435954d000c326e55ea363576b8',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/37ae41b7150d1b1b8fe0be906bd6e6d3.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24111a9d0e634335c4edee9f587f3bbe',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/5a6198047f340d9b32e7a8fcb05645bf.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db4799a609e81a58dccbed2e7bafff36',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/b28fff1c3d65aeb4eb7dc03033eba7c8.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e827d216c61a472b90b8b79072df07d3',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/a141c9ee1e38a217ac4408032ba56240.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a54dfe93853038416fa2621f8e4dca1',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/821dd6f8ff90e1b98014bf8f34015973.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31ec9b631088f564b96e42f1ba8a1088',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/5c9074581f3d704e175e640b887e7961.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a31771a9de0ef42c3791dca060d6fd62',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/aa235e148591fb763b2a356b3e8a3573.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'caeac03d92028b0d4362813290d6087d',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/11303629648777c5f90f0073b97f990c.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '268ba76a1bad61597d1b717d143cb9b2',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/7e96b9b1c0537b9264aaf4f64f367e09.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe682630d77662e344484b39625419c8',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/603d0a9af47b8e653bc5469b88b344f2.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef7947bf8f841182bfb92b1651e6b4d9',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/4fe50e68ff2eb3c6ff69a32f3e976636.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42065abfc06ef783a668b505d39c0cd3',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/5a0e0e547451709a1080a031ee11d8a5.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8580e5a4879726ae5792134ea812a78',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/d45e1c4027bb92c1ef20162ff30128ff.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '377d66059cde5f0fec2984ab4d85f874',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/190b2dcf91f7aca05222dbc18fbeb87d.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfa2cabcd30ae7a450c0faea0040e7f0',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/d86a3b948d3cee7aa0c6f166e37a137b.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba9505d7fb729cba61cf074e30175e87',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/3b3ff92674d9e5861d9f358807033855.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d65c7d6f505eca840c12cc66079f645',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/edba5a3c87f1581be824c569c60c5ab3.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b93ae9dbd2b77a2c4e0716fb99b1058f',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/48f029b0820a24110fac6499ea4131a8.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ff4222047ee3110ff9592947137c495',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/ecab992499396442c1252d7b5aa1f666.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71ee652e3a1a7bd5856c4a8730ee2b24',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/0387605251e56e91b87a364da2319084.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90230e1a6a9a8ec401b79284cbfa4361',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/3ed3034ad8a1061128c12d6aa1379b36.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28bcc53b72856eeb1c05c0d2383102af',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/d8d6d58a282db33a8dba67871bc57c19.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4c06d01232a0b32478d9f74808ff523',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/3d4f2a6a155b8370e97a3c5d5b2499a0.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83441aed5ed1b648e49f15fb2fa77efb',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/a9e35bb8d32846a2d4c9b8aa96837204.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd34a474e9dfd65f52ebcaa3034e4bbc',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/aaf558309b68c9eddd3729089e052e88.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f33d9e8dd5158e2d7a484baa1f66aec7',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/1d2aa84aea16c915e8bacc528d04ba11.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '35e43897bc67ce00d72a50b9e9fe9181',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/ffddf363f5dd3f7fc2f43c02a22c40a5.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '45041ee43ca8125e221002e16b67ac19',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/6d54e49294754b81a305d35555840c27.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '1aba5dd7f1765e5c8549e50bd3b70579',
      'native_key' => 1,
      'filename' => 'modUserGroup/af85d6e3f30575890a163d5645d22298.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '4bcf928153036bf742e3615b6179639c',
      'native_key' => 1,
      'filename' => 'modDashboard/7a6a3d3f4e05dbfac7f5005179f9ada1.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '0ecd7c0ec7d83fe7181bb77d940c5298',
      'native_key' => 1,
      'filename' => 'modMediaSource/fcbb612bf4ff73319efff6d0ac3d497c.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e5cf37f6b14bef4eb7515d8a3f05dcee',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4ee4119d9227cc7748ff4c89994a7663.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '8f0a07ffc7327b225bc098c0d9a992ed',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/913eb423a7e5a4a84ccbe974d7901d3d.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f158034f5d271a80d1643e5a913e3bb4',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/0bbf40517cc89c83fc9848d9881d1cce.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd3ae5f6d63b4ef61f28c8f0ec92795c8',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/69242feb6dcec6f85dbe124a29e79877.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '77c1960b7fa26a3d1bdf64b09025fec9',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/52f41004920b558b4e6cf6cbcfd1380f.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '0ff5b1bc4025e8cf48834215da1f4530',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/3ed76de26e3f73883b2aacb4e3d0685c.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'fc2830c3b84def61b4ded9288f1bf162',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/eeb1486605579af9d0f42692dc386c5a.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0ffa02e4460214362f3cf29c54d7a1b4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/4930f61f2291a73d98931ab362ace4b5.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '4f79e0e5b97d99b4698561c1ef11efc8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/0449554473165bb0f8d68d3dbe610d0f.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'aa38bab639482d685e72d6706a9f929d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/93babf7493c7608b592129c1a170151c.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '2c9008f30c8b40ed19be138ce5f6e9cf',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/f982b37a4ad18b4833e8bb7dbbf805fe.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'cb4eecd9c2a5056ea15c27b5762d7a76',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/4126d474daf12a111b351f5c8c28442b.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'da5bc9c57b4320e72eb0221968541c11',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b276eed9a8b5c188ae2eeb4fd0b37ff5.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a012a2ccc5076ba66b7afeb761e98e6f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/cea085e3665d9d9c09d317db069cd500.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '708855633e59a1c12973e9a5e1b29dc0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/80e33e2cb5a32c325540bbecd6c6db34.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '2c75b913b1efeeccf25d40c307beb4a1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f01c3b3941e0ce0c37e412642e8599ec.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '020d2585f889cf36910f1f1be5cd244a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b73c57b2207ff0d28bb4586ebbe1ee41.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '779c78a182b231d1a0e6fecc5ed78818',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c18dd548bbc807f349fed49a23256487.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '958f61c0b83e269e20cdb23ed2d9c2e2',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/83cf1d25a74822288cbdd780f666135e.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1aa706f926d4f8c89410f319be2d7d64',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/6696b8ac23bbdca8598093ae16113abd.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '30aeea9d713e2c3c21013c30076ea3ce',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/be843c2f178b9dbc79e55549b0faba78.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f224ee97d76f76459f3d5b3a1be12f66',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/778a9a69d5c62014d750110253098dd5.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0c0e72f27389f5acf42e105b7d036657',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/8be88028680656c7aac2ea8b0bae4fc5.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ca464724974fea5cb73fdf3415c63437',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/96f2dd35b32b27d0da091a185699a7b3.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8466ed6a698ee66e8d2cd025851231c4',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/74ea7aa162a1d0eb37c614f472d4981f.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4ffcb9ff697ee04afafa7d1941975fdf',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/db356f7f01d81eef65092f125b8a539f.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '709e07cf5dae9844801dff7fa4179425',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/16ff8e12717f8c4dfc9271d6c0fdfcdf.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '54b6783bf1350210c0ac54ba461fe101',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/ed9e05233c3c947faba6f73f361162ec.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '42fec45adda8c6eb01ca566aed1df33d',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/0514b8f42fc09fb0bfdab2b64e945221.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '1ecf60c900516f6a48b19c3b3ef5e2d6',
      'native_key' => 'web',
      'filename' => 'modContext/5330eecd85c4f28fb787035f79454a5b.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '6d558d14d98cd48c159dea3c9190bb30',
      'native_key' => 'mgr',
      'filename' => 'modContext/c7cfd27391afc533ea322ef101caa35a.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e6e06eaa870dbcd772c317ca91ac757c',
      'native_key' => 'e6e06eaa870dbcd772c317ca91ac757c',
      'filename' => 'xPDOFileVehicle/fddc49531fee86de67684a131fe46ec0.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5b31319b68cd183ad1a75267cfe0f7ab',
      'native_key' => '5b31319b68cd183ad1a75267cfe0f7ab',
      'filename' => 'xPDOFileVehicle/8ba17ea3f44937d4bf74223e3394d8ba.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8e6f14d1c961521aa7ccf0504a5fc8e1',
      'native_key' => '8e6f14d1c961521aa7ccf0504a5fc8e1',
      'filename' => 'xPDOFileVehicle/4b7e1f52e8fe592ee846de5817d9a0fb.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '3dc318bcb3ce0ccc6d76358d53c6953f',
      'native_key' => '3dc318bcb3ce0ccc6d76358d53c6953f',
      'filename' => 'xPDOFileVehicle/71aac4f12bb9dc66133e39cc0bf39dd2.vehicle',
    ),
  ),
);